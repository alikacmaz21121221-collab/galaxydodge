// submit-score.js
// Example Netlify Function that inserts a score into Supabase.
// Requires SUPABASE_URL and SUPABASE_KEY to be set as environment variables in Netlify.

const fetch = require('node-fetch');

exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  const body = JSON.parse(event.body || '{}');
  const name = (body.name || 'Player').slice(0,64);
  const score = Number(body.score || 0);
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_KEY;
  if (!SUPABASE_URL || !SUPABASE_KEY) return { statusCode: 500, body: 'Supabase not configured' };

  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/scores`, {
      method: 'POST',
      headers: {
        'Content-Type':'application/json',
        'apiKey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`
      },
      body: JSON.stringify([{ name, score }])
    });
    const json = await res.text();
    return { statusCode: 200, body: json };
  } catch (err) {
    return { statusCode: 500, body: String(err) };
  }
};
