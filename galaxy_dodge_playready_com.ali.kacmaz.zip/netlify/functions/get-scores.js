// get-scores.js
// Example Netlify Function that fetches top scores from Supabase (ordered desc).
const fetch = require('node-fetch');
exports.handler = async function(event, context) {
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_KEY;
  if (!SUPABASE_URL || !SUPABASE_KEY) return { statusCode: 500, body: 'Supabase not configured' };
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/scores?select=*&order=score.desc&limit=50`, {
      method: 'GET',
      headers: { 'apiKey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` }
    });
    const json = await res.text();
    return { statusCode: 200, body: json };
  } catch (err) {
    return { statusCode: 500, body: String(err) };
  }
};
